@extends('master')
@section('page-content')
           <div class="row" style="margin-top: 30px">
            <div class="col-md-3">
                <div class="card share share-other col1" data-social="item" style="width: 100%">
                      <div class="circle" data-toggle="tooltip" title="Label" data-container="body">
                      </div>
                      <div class="card-content">
                        <ul class="buttons ">
                          <li>
                            <a href="#"><i class="fa fa-expand"></i>
										</a>
                          </li>
                          <li>
                            <a href="#"><i class="fa fa-heart-o"></i>
										</a>
                          </li>
                        </ul>
                       <img alt="Quote" src="public/img/newspeper/1.jpeg">
                      </div>
                      
                      <div class="card-header clearfix">
                        <div class="user-pic">
                          
                        </div>
                          <h4><strong>Prothom Alo</strong></h4>
                      </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card share share-other col1" data-social="item" style="width: 100%">
                      <div class="circle" data-toggle="tooltip" title="Label" data-container="body">
                      </div>
                      <div class="card-content">
                        <ul class="buttons ">
                          <li>
                            <a href="#"><i class="fa fa-expand"></i>
										</a>
                          </li>
                          <li>
                            <a href="#"><i class="fa fa-heart-o"></i>
										</a>
                          </li>
                        </ul>
                        <img alt="Quote" src="public/img/newspeper/2.jpg">
                      </div>
                      
                      <div class="card-header clearfix">
                        <div class="user-pic">
                          
                        </div>
                          <h4><strong>Jugantor</strong></h4>
                      </div>
                    </div>
            </div>
            <div class="col-md-3">
                <div class="card share share-other col1" data-social="item" style="width: 100%">
                      <div class="circle" data-toggle="tooltip" title="Label" data-container="body">
                      </div>
                      <div class="card-content">
                        <ul class="buttons ">
                          <li>
                            <a href="#"><i class="fa fa-expand"></i>
										</a>
                          </li>
                          <li>
                            <a href="#"><i class="fa fa-heart-o"></i>
										</a>
                          </li>
                        </ul>
                        <img alt="Quote" src="public/img/newspeper/11.jpg">
                      </div>
                      
                      <div class="card-header clearfix">
                        <div class="user-pic">
                         
                        </div>
                          <h4><strong>bdnews24.com</strong></h4>
                      </div>
                    </div>
            </div>
            <div class="col-md-3">
                <div class="card share share-other col1" data-social="item" style="width: 100%">
                      <div class="circle" data-toggle="tooltip" title="Label" data-container="body">
                      </div>
                      <div class="card-content">
                        <ul class="buttons ">
                          <li>
                            <a href="#"><i class="fa fa-expand"></i>
										</a>
                          </li>
                          <li>
                            <a href="#"><i class="fa fa-heart-o"></i>
										</a>
                          </li>
                        </ul>
                        <img alt="Quote" src="public/img/newspeper/4.jpg">
                      </div>
                      
                      <div class="card-header clearfix">
                        <div class="user-pic">
                          
                        </div>
                          <h4><strong>The Daily Star</strong></h4>
                      </div>
                    </div>
            </div>
               
            </div>
            <div class="row">
                <div class="col-md-3">
                <div class="card share share-other col1" data-social="item" style="width: 100%">
                      <div class="circle" data-toggle="tooltip" title="Label" data-container="body">
                      </div>
                      <div class="card-content">
                        <ul class="buttons ">
                          <li>
                            <a href="#"><i class="fa fa-expand"></i>
										</a>
                          </li>
                          <li>
                            <a href="#"><i class="fa fa-heart-o"></i>
										</a>
                          </li>
                        </ul>
                       <img alt="Quote" src="public/img/newspeper/5.png">
                      </div>
                      
                      <div class="card-header clearfix">
                        <div class="user-pic">
                          
                        </div>
                          <h4><strong>Bangladesh Pratidin</strong></h4>
                      </div>
                    </div>
            </div>
            <div class="col-md-3">
                <div class="card share share-other col1" data-social="item" style="width: 100%">
                      <div class="circle" data-toggle="tooltip" title="Label" data-container="body">
                      </div>
                      <div class="card-content">
                        <ul class="buttons ">
                          <li>
                            <a href="#"><i class="fa fa-expand"></i>
										</a>
                          </li>
                          <li>
                            <a href="#"><i class="fa fa-heart-o"></i>
										</a>
                          </li>
                        </ul>
                        <img alt="Quote" src="public/img/newspeper/5.jpg">
                      </div>
                      
                      <div class="card-header clearfix">
                        <div class="user-pic">
                          
                        </div>
                          <h4><strong>Kaler Kontho</strong></h4>
                      </div>
                    </div>
            </div>
            <div class="col-md-3">
                <div class="card share share-other col1" data-social="item" style="width: 100%">
                      <div class="circle" data-toggle="tooltip" title="Label" data-container="body">
                      </div>
                      <div class="card-content">
                        <ul class="buttons ">
                          <li>
                            <a href="#"><i class="fa fa-expand"></i>
										</a>
                          </li>
                          <li>
                            <a href="#"><i class="fa fa-heart-o"></i>
										</a>
                          </li>
                        </ul>
                        <img alt="Quote" src="public/img/newspeper/7.jpg">
                      </div>
                      
                      <div class="card-header clearfix">
                        <div class="user-pic">
                         
                        </div>
                          <h4><strong>Daily Inqilab</strong></h4>
                      </div>
                    </div>
            </div>
            <div class="col-md-3">
                <div class="card share share-other col1" data-social="item" style="width: 100%">
                      <div class="circle" data-toggle="tooltip" title="Label" data-container="body">
                      </div>
                      <div class="card-content">
                        <ul class="buttons ">
                          <li>
                            <a href="#"><i class="fa fa-expand"></i>
										</a>
                          </li>
                          <li>
                            <a href="#"><i class="fa fa-heart-o"></i>
										</a>
                          </li>
                        </ul>
                        <img alt="Quote" src="public/img/newspeper/12.jpg">
                      </div>
                      
                      <div class="card-header clearfix">
                        <div class="user-pic">
                          
                        </div>
                          <h4><strong>Manabjamin</strong></h4>
                      </div>
                    </div>
            </div>
               
        </div>
@endsection
 
