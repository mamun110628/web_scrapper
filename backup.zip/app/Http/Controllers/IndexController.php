<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Goutte\Client;
use Symfony\Component\HttpClient\HttpClient;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use PDF;
use \DataTables;
use Illuminate\Support\Facades\Redirect;

class IndexController extends Controller {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request) {
        $search_query = $request->q;
        
        $base_url = 'https://www.jugantor.com/';
        $client = new Client(HttpClient::create(['timeout' => 60]));
        $crawler = $client->request('GET', $base_url);
        $links = $crawler->selectLink($search_query)->links();
        $data = array();
        $url = array();
        foreach ($links as $key=>$link) {
            $url_link = $link->getUri();
            if(isset($url) and in_array($url_link, $url)){
                continue;
            }
            $crawler = $client->click($link);
            $data[] = $crawler->filter('h1,.dtl_img_section p,.dtl_img_section img')->each(function ($node) use ($base_url) {
                
                

                if ($node->getNode(0)->nodeName == 'img') {
                    $data['image'] = '<img src="' . $base_url . $node->getNode(0)->getAttribute('src') . "\" />";
                }elseif($node->getNode(0)->nodeName == 'h1'){
                 $data['h1'] = '<h1>'.$node->text().'</h1>';
                }else{
                    $data['text'] = $node->text();
                }
                return $data;
            });
            
             $url[$key] = $url_link;
        }
        
        return view('paper_view', compact('data',$url));
    }
    public function search(){
       return view('search'); 
    }
    
    public function collectNews(){
        $newspaper = \App\Model\Newspaper::all();
       return view('news.collect_news', compact('newspaper'));  
    }
    public function NewsCollect(Request $request){
         $session_data = Session::get('login_detail');
        $newspaper = \App\Model\Newspaper::find($request->newspaper);
        if($newspaper){
            
        
        $base_url = $request->newspaper;
        $url = $request->url;
        $client = new Client(HttpClient::create(['timeout' => 60]));
        $crawler = $client->request('GET', $url);
         $data[] = $crawler->filter($newspaper->dom_element)->each(function ($node) use ($newspaper) {
                if ($node->getNode(0)->nodeName == 'img') {
                    $data['image'] = '<img src="'.$newspaper->image_base_url. $node->getNode(0)->getAttribute('src') . "\" />";
                }elseif($node->getNode(0)->nodeName == 'h1'){
                 $data['headline'] = '<h1>'.$node->text().'</h1>';
                }elseif($node->getNode(0)->nodeName == 'h2'){
                 $data['headline'] = '<h2>'.$node->text().'</h2>';
                }elseif($node->getNode(0)->nodeName == 'h3'){
                 $data['headline'] = '<h3>'.$node->text().'</h3>';
                }elseif($node->getNode(0)->nodeName == 'h4'){
                 $data['headline'] = '<h4>'.$node->text().'</h4>';
                }elseif($node->getNode(0)->nodeName == 'h5'){
                 $data['headline1'] = '<h5>'.$node->text().'</h5>';
                }else{
                    $data['text'] = $node->text();
                }
                return $data;
            });
            $text = '';
            $image = '';
            $headline = '';
            $spechial_comment = '';
             $i= 0;
             $h = 0;
            foreach ($data as $datam) {
                foreach ($datam as $value) {
                    if (isset($value['image'])) {
                        $image .= $value['image'];
                    } elseif (isset($value['headline'])) {
                        if ($h == 0) {
                            $headline .=$value['headline'];
                            $h++;
                        }
                    } elseif (isset($value['headline1'])) {
                        $spechial_comment .= $value['headline1'];
                    } else {
                        $text .=$value['text'];
                    }
                    $i++;
                }
            }
            
            $news = new \App\Model\News();

            $data['data'] = $data;
            $data['paper_name'] = $newspaper->name;
            $pdf = PDF::loadView('paper_view', $data);
            $file_name = time().'.pdf';
            
            $pdf->save(storage_path('upload').'/' . $file_name);
             
            
            $news->headline = $headline;
            $news->spechial_news = $spechial_comment;
            $news->news_description = $text;
            $news->image_link  = $image;
            $news->news_url  = $url;
            $news->collected_by = $session_data['login_id'];
            $news->news_date = date('Y-m-d');
            $news->pdf_file = $file_name;
             $news->newspaper_id = $newspaper->id;
              $news->newspaper_name = $newspaper->name;
            if($news->save()){
                return redirect(url('news-list'))
                 ->with('success', 'Collected Successfully');
            }
            
       
       }else{
           return redirect()->back()
            ->with('error', 'No Data Found');
       }
            
    }
    
    public function NewsList(){
         return view('news.news_list');
    }
    public function newsAjaxList(){
         $newslist = \App\Model\News::all();
        return Datatables::of($newslist)
                        ->addColumn('pdf_file', function($value) {
                            $action = '<a href="' . url('storage/upload/', $value->pdf_file) . '" class="btn btn-primary" target="__blank">View Details</a>';

                            return $action;
                        })
                        ->addColumn('headline', function($value) {
                            $headline = strip_tags($value->headline);

                            return $headline;
                        })
                        ->addColumn('checkbox',function($value){
                            $checkbox = '<input type="checkbox" class="check_id" name="pdf_id[]" value="'.$value->id.'">';
                            return $checkbox;                    
                        })
                        ->rawColumns(['headline','pdf_file','checkbox'])
                        ->make(true);
    }

   public function makePdf(Request $request){
        $news_id = $request->check_all;
        $ids = explode('_', $news_id);
        foreach ($ids as $key => $value) {
            $news[] = \App\Model\News::find($value);
        }
        
         $data['data'] = $news;
          
            $pdf = PDF::loadView('make_paper_archive', $data);
            $file_name = time().'.pdf';
            
            $pdf->save(storage_path('upload').'/' . $file_name);
            $return_array = array(
                'status'=>200,
                'download_url' =>'upload'.'/' . $file_name
            );
            return json_encode($return_array);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id) {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id) {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        //
    }

}
